# 🚀 Rocket Math Automation Extension

A Chrome Extension (Manifest V3) that automates solving "Equivalent Fractions" levels on [play.rocketmath.com](https://play.rocketmath.com) using Groq's Vision API.

## Features

- ✅ **Automated Solving**: Uses Groq's `llama-3.2-11b-vision-preview` model to analyze game screenshots and solve fraction problems
- ⏱️ **Rate Limiting**: Built-in 2-second delay between actions to respect Groq's 30 RPM free tier limit
- 🎮 **Manual Control**: Start/Stop toggle in popup UI for full control
- 🔐 **Secure Storage**: API key stored locally using Chrome's storage API
- 🎨 **Modern UI**: Beautiful Angular-based popup with gradient design and status indicators

## Installation

### 1. Get Your Groq API Key

1. Visit [console.groq.com](https://console.groq.com)
2. Sign up or log in
3. Navigate to API Keys section
4. Create a new API key
5. Copy the key (starts with `gsk_...`)

### 2. Load the Extension

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable **Developer mode** (toggle in top-right corner)
3. Click **Load unpacked**
4. Select this extension directory: `c:\Users\matte\OneDrive\Desktop\Coding Stuff\Websites-anything web\Rocketmath automation thing`
5. The extension icon should appear in your Chrome toolbar

## Usage

### First Time Setup

1. Click the extension icon in your Chrome toolbar
2. Enter your Groq API key in the input field
3. The key will be saved automatically

### Running the Bot

1. Navigate to [https://play.rocketmath.com](https://play.rocketmath.com)
2. Log in to your account (or use direct link with credentials)
3. Start an "Equivalent Fractions" level
4. Click the extension icon
5. Click **Start Bot**
6. Watch the bot automatically solve problems!

### Stopping the Bot

- Click the extension icon
- Click **Stop Bot**

## How It Works

1. **Canvas Capture**: Every 2 seconds, the extension captures the game canvas as a PNG image
2. **Vision API**: The image is sent to Groq's Vision API with a prompt asking to solve the fraction problem
3. **Answer Extraction**: The API response is parsed to extract just the numeric answer
4. **Automation**: The answer is typed into the game input field and Enter is pressed
5. **Rate Limiting**: 2-second delay ensures we stay within the 30 requests/minute limit

## Technical Details

### Files Structure

```
Rocketmath automation thing/
├── manifest.json          # Extension configuration (Manifest V3)
├── popup.html            # Popup UI (Angular)
├── popup.js              # Popup controller logic
├── styles.css            # Modern CSS styling
├── content.js            # Main automation script
├── background.js         # Service worker
├── icon16.svg            # 16x16 icon
├── icon48.svg            # 48x48 icon
├── icon128.svg           # 128x128 icon
└── README.md             # This file
```

### API Prompt

The extension sends this prompt to Groq Vision API:

> "This is a math game showing an equivalent fraction problem, its called RocketMath. Find the missing number in the fraction in simplest form and respond with ONLY the number, nothing else."

### Permissions

- `activeTab`: Access to the current tab when extension is clicked
- `storage`: Store API key and bot state
- `scripting`: Inject content script into Rocket Math pages
- `host_permissions`: Access to play.rocketmath.com

## Troubleshooting

### Bot Not Working

1. **Check Console**: Open DevTools (F12) and check for error messages
2. **Verify API Key**: Make sure your Groq API key is correct
3. **Check Canvas**: Ensure the game is using a `<canvas>` element
4. **Rate Limit**: If you see 429 errors, you've hit the rate limit - wait a minute

### Input Not Detected

- The bot looks for the active input element
- Make sure the game has focus on an input field
- Try clicking on the answer box before starting the bot

### API Errors

- **401 Unauthorized**: Invalid API key
- **429 Too Many Requests**: Rate limit exceeded
- **503 Service Unavailable**: Groq API is down

## Safety & Disclaimer

⚠️ **Use at your own risk**: This bot automates gameplay on Rocket Math. While it includes manual controls, automated gameplay may violate the site's terms of service.

## License

MIT License - Feel free to modify and use as needed!

## Credits

- Built with Chrome Extension Manifest V3
- Powered by [Groq Cloud API](https://groq.com)
- UI framework: [AngularJS](https://angularjs.org)
